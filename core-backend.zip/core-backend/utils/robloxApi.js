const axios = require("axios");

async function fetchGameData(placeIds) {
  const url = \`https://games.roblox.com/v1/games?universeIds=\${placeIds.join(",")}\`;
  const { data } = await axios.get(url);
  return data.data;
}

async function fetchGroupData(groupIds) {
  const responses = await Promise.all(
    groupIds.map(id =>
      axios.get(\`https://groups.roblox.com/v1/groups/\${id}\`).then(res => res.data)
    )
  );
  return responses;
}

module.exports = { fetchGameData, fetchGroupData };