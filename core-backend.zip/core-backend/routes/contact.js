const express = require("express");
const router = express.Router();
const axios = require("axios");

router.post("/", async (req, res) => {
  const { name, email, subject, message } = req.body;
  const webhook = process.env.DISCORD_WEBHOOK;
  try {
    await axios.post(webhook, {
      content: `📩 **New Contact Message**\n**From:** ${name} (${email})\n**Subject:** ${subject}\n**Message:** ${message}`
    });
    res.status(200).json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to send webhook" });
  }
});

module.exports = router;