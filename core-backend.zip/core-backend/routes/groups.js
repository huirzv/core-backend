const express = require("express");
const router = express.Router();
const { fetchGroupData } = require("../utils/robloxApi");

const groupIds = [
  8927586, 4595505, 33205238, 33504510, 34817411,
  32386245, 17351356, 32815300, 11919869, 33862880
];

router.get("/", async (req, res) => {
  try {
    const data = await fetchGroupData(groupIds);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch group data" });
  }
});

module.exports = router;