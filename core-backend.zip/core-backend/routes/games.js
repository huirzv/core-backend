const express = require("express");
const router = express.Router();
const { fetchGameData } = require("../utils/robloxApi");

// Replace with your actual universeIds
const gameIds = [
  15862468045, 14684875878, 108277447736825, 6321891709, 17428520796,
  14973253793, 16347356597, 7282854346, 15163154086
];

router.get("/", async (req, res) => {
  try {
    const data = await fetchGameData(gameIds);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch game data" });
  }
});

module.exports = router;