const express = require("express");
const router = express.Router();
const { fetchGameData, fetchGroupData } = require("../utils/robloxApi");

const gameIds = [
  15862468045, 14684875878, 108277447736825, 6321891709, 17428520796,
  14973253793, 16347356597, 7282854346, 15163154086
];

const groupIds = [
  8927586, 4595505, 33205238, 33504510, 34817411,
  32386245, 17351356, 32815300, 11919869, 33862880
];

router.get("/", async (req, res) => {
  try {
    const games = await fetchGameData(gameIds);
    const groups = await fetchGroupData(groupIds);

    const totalMembers = groups.reduce((sum, g) => sum + g.memberCount, 0);
    const activePlayers = games.reduce((sum, g) => sum + g.playing, 0);
    const totalVisits = games.reduce((sum, g) => sum + g.visits, 0);

    res.json({
      totalMembers,
      activePlayers,
      totalVisits,
      gamesCreated: games.length
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

module.exports = router;